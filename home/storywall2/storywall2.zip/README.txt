A Pen created at CodePen.io. You can find this one at https://codepen.io/Chessy/pen/JyemwV.

 Using :hover and the sibling selector (~), we can apply different styles to elements based on their position. Removing the visibility transition  gets rid of the previous element's ghost for a cleaner slide-in with no slide-out. Layout and images are auto-generated with Pug. Refresh for something different,

<a href="http://codepen.io/giana/pen/dWJzMK/">A simplified pen</a> if you have trouble understanding how it works.